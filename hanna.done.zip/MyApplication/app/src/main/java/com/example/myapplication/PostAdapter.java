package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PostAdapter  extends RecyclerView.Adapter<PostAdapter.ViewHolder>  {

    private final Context context;
    private final ArrayList<PostItem> postItemArrayList;


    public PostAdapter(Context context, ArrayList<PostItem> postItemArrayList) {
        this.context = context;
        this.postItemArrayList = postItemArrayList;
    }

    @NonNull
    @Override
    public PostAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull PostAdapter.ViewHolder holder, int position) {
        PostItem postItem = postItemArrayList.get(position);
        holder.titlePost.setText(postItem.getTitle());
        holder.descriptionPost.setText("" + postItem.getDescription());
        Picasso.get().load(postItem.getPic()).into(holder.imgPost);


    }

    @Override
    public int getItemCount() {
        return postItemArrayList.size();

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView imgPost;
        private final TextView titlePost;
        private final TextView descriptionPost;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPost = itemView.findViewById(R.id.idUserImage);
            titlePost = itemView.findViewById(R.id.idUserName);
            descriptionPost = itemView.findViewById(R.id.iduserMail);
        }
    }


}


