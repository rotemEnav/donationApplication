package com.example.myapplication;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.widget.AutocompleteFragment;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PostFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PostFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public PostFragment() {
        // Required empty public constructor
    }

    public static PostFragment newInstance(String param1, String param2) {
        PostFragment fragment = new PostFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    private DatabaseReference myRef;
    private StorageReference storage;





    Button PostBtn;
    ImageButton ImageBtn;
    String title = "";
    EditText DescriptionET, PhoneET, AddressET, EmailET, TitleET;
    PostItem postItem;
    TextView DeliveryTview;

    Uri imageUri = null;
    private static final int GALLERY_IMAGE_CODE = 100;
    private static final int CAMERA_IMAGE_CODE = 200;

    String pic = "";
    private ProgressDialog progressBar;
    FirebaseAuth auth;
    Spinner spinner;
    //continue from minute
    String picTitle = "";
    String picUrl = "";
    String[] categories;
    String categoryChosen;
    ArrayAdapter ad;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_post, container, false);
        myRef = FirebaseDatabase.getInstance().getReference().child("Post");


        //auto complite

        // Initialize the AutocompleteSupportFragment.
        AutocompleteSupportFragment autocompleteFragment = (AutocompleteSupportFragment)
                getChildFragmentManager().findFragmentById(R.id.autocomplete_fragment);
        Places.initialize(getContext(), getResources().getString(R.string.google_maps_key));
        PlacesClient placesClient = Places.createClient(getContext());

        // Specify the types of place data to return.
        autocompleteFragment.setPlaceFields(Arrays.asList(Place.Field.ID, Place.Field.NAME));

        // Set up a PlaceSelectionListener to handle the response.
        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                // TODO: Get info about the selected place.
                Log.i(TAG, "Place: " + place.getName() + ", " + place.getId());
            }


            public void onError(@NonNull Status status) {
                // TODO: Handle the error.
                Log.i(TAG, "An error occurred: " + status);
            }
        });
        //end of auto complete



        categories = new String[]{"furniture", "toys", "bedroom items"};


       storage = FirebaseStorage.getInstance().getReference();
        spinner = v.findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                categoryChosen = categories[i];

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        ad = new ArrayAdapter(getContext(), android.R.layout.simple_spinner_item, categories);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(ad);
        ImageBtn = v.findViewById(R.id.imageButton);
        DescriptionET = v.findViewById(R.id.description_edittext);
        PhoneET = v.findViewById(R.id.phone_edittext);
        EmailET = v.findViewById(R.id.email_edittext);
        PostBtn = v.findViewById(R.id.post_btn);
        TitleET = v.findViewById(R.id.editTextText);
        auth = FirebaseAuth.getInstance();

        ImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (DescriptionET.getText().toString().length() == 0)
                {
                                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                                    alertDialog.setTitle("you must enter a description about your item before selecting an image");
                                    alertDialog.setMessage("Enter Title");

                                    final EditText input = new EditText(getContext());
                                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                                            LinearLayout.LayoutParams.MATCH_PARENT,
                                            LinearLayout.LayoutParams.MATCH_PARENT);
                                    input.setLayoutParams(lp);
                                    alertDialog.setView(input);
                                    alertDialog.setIcon(R.drawable.key);

                                    alertDialog.setPositiveButton("save",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    title = input.getText().toString();
                                                    DescriptionET.setText(title);
                                                    imagePickDialog();
                                                }
                                            });

                                    alertDialog.setNegativeButton("cancel",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.cancel();
                                                }
                                            });
                                    alertDialog.show();




                }
                else
                    imagePickDialog();

                }});



        PostBtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Boolean isFull = true;
            String phoneNumber = PhoneET.getText().toString();
            String desc = DescriptionET.getText().toString();

            if (TextUtils.isEmpty(TitleET.getText().toString())) {
                isFull = false;
                TitleET.setError("Please type title");
            }

            if (TextUtils.isEmpty(PhoneET.getText().toString())) {
                isFull = false;
                PhoneET.setError("Please type title");
            }

            if (TextUtils.isEmpty(DescriptionET.getText().toString())) {
                isFull = false;
                DescriptionET.setError("Please type description");
            }

            if (TextUtils.isEmpty(EmailET.getText().toString())) {
                isFull = false;
                EmailET.setError("Please type title");
            }



            if (isFull) //all is full
            {
                //    public PostItem(String pic, String category, String description, String phonenumber, String email, String addreass) {



                postItem= new PostItem(SignIn.userid+"", TitleET.getText().toString(), picUrl, categoryChosen, DescriptionET.getText().toString(),PhoneET.getText().toString(), EmailET.getText().toString(), "" );
                myRef.child( String.valueOf(UUID.randomUUID())).setValue(postItem);
                Toast.makeText(getContext(), "your post has been uploaded",Toast.LENGTH_SHORT).show();


                Fragment fragment = new HomeFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

            }
        }
    });
        return v;
}



    private void imagePickDialog() {

        String[]options = {"gallery", "camera"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Choose image from");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                if(i == 0){

                    galleryPick();

                }

                if(i == 1){

                    cameraPick();

                }

            }
        });
        builder.create().show();

    }

    private void cameraPick() {


        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, CAMERA_IMAGE_CODE);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {

            if (requestCode == GALLERY_IMAGE_CODE) {

                imageUri = data.getData();
                ImageBtn.setImageURI(imageUri);

            }
            if (requestCode == CAMERA_IMAGE_CODE) {


                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                ImageBtn.setImageBitmap(imageBitmap);

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data1 = baos.toByteArray();



                UploadTask uploadTask = storage.child("profile").child(System.currentTimeMillis()+"").putBytes(data1);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
// taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        // ...
                        Task<Uri> uri = taskSnapshot.getStorage().getDownloadUrl();
                        while (!((Task<?>) uri).isComplete()) ;
                        Uri url = uri.getResult();
                        picUrl = url.toString();

                    }
                });

            }
        }
    }
    private void galleryPick() {

        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, GALLERY_IMAGE_CODE);

    }




}




