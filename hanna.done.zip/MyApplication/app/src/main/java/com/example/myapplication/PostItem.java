package com.example.myapplication;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class PostItem implements Serializable, Parcelable {

    String pic;
    String category;
    String description;
    String phonenumber;
    String email;
    String address;
    String title;

    String postWriter ;

    public String getPostWriter() {
        return postWriter;
    }

    public void setPostWriter(String postWriter) {
        this.postWriter = postWriter;
    }

    public PostItem() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public PostItem(String postWriter, String title, String pic, String category, String description, String phonenumber, String email, String addreass) {
        this.postWriter = postWriter;
        this.title = title;
        this.pic = pic;
        this.category = category;
        this.description = description;
        this.phonenumber = phonenumber;
        this.email = email;
        this.address = addreass;
    }

    protected PostItem(Parcel in) {
        pic = in.readString();
        category = in.readString();
        description = in.readString();
        phonenumber = in.readString();
        email = in.readString();
        address = in.readString();
    }

    public static final Creator<PostItem> CREATOR = new Creator<PostItem>() {
        @Override
        public PostItem createFromParcel(Parcel in) {
            return new PostItem(in);
        }

        @Override
        public PostItem[] newArray(int size) {
            return new PostItem[size];
        }
    };

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddreass() {
        return address;
    }

    public void setAddreass(String addreass) {
        this.address = addreass;
    }

    @Override
    public String toString() {
        return "PostItem{" +
                "pic='" + pic + '\'' +
                ", category='" + category + '\'' +
                ", description='" + description + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", email='" + email + '\'' +
                ", addreass='" + address + '\'' +
                ", title='" + title + '\'' +
                ", postWriter='" + postWriter + '\'' +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(pic);
        parcel.writeString(category);
        parcel.writeString(description);
        parcel.writeString(phonenumber);
        parcel.writeString(email);
        parcel.writeString(address);
    }
}
