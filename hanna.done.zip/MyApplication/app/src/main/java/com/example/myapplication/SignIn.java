package com.example.myapplication;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SignIn extends AppCompatActivity  {
    EditText userNameEditText, passwordEditText;
    Button signInButton;
    ArrayList<User> userArrayList ;
    ArrayList<PostItem> postArrayList;


    ArrayList<String> test  = new ArrayList<>();

    TextView forgotPasswordtextView, signupTextView;
    String email, password;
    static String userid = "";
     FirebaseAuth mAuth;
    SharedPreferences sp;

    final int SIGN_UP = 1;


    CheckBox stayConnect;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);

         postArrayList = new ArrayList<>();
        userArrayList = new ArrayList<>();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("DATA");
        mAuth = FirebaseAuth.getInstance();
        stayConnect = findViewById(R.id.checkBox);
        userNameEditText = findViewById(R.id.emailET);
        passwordEditText = findViewById(R.id.password);
        signInButton = findViewById(R.id.Start);
        forgotPasswordtextView = findViewById(R.id.Forgotpassword);
        signupTextView = findViewById(R.id.SignUpBtn);


        sp = getSharedPreferences("userList",MODE_PRIVATE);  //MODE_PRIVATE - for this app only
        if (sp.getBoolean("stayConnect", false)) { //if "not_first_run" isn't exist the default value will be false else true
            userNameEditText.setText(sp.getString("username", ""));
            passwordEditText.setText(sp.getString("password", ""));
            stayConnect.setChecked(true);
        }



        Query q = myRef.child("users");
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dst: snapshot.getChildren() )
                {
                    User u = dst.getValue(User.class);
                    userArrayList.add(u);
                    test.add("kobi");
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });
        System.out.println("user "+ test);

        System.out.println("user "+userArrayList);


        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (userNameEditText.getText().toString().length() != 0 && passwordEditText.getText().toString().length() != 0) {
                    email = userNameEditText.getText().toString();
                    password = passwordEditText.getText().toString();
                    mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(SignIn.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    userid = user.getUid();

                                    allDataDownload();
                                    startActivity(new Intent(SignIn.this,NavBar.class));

                                    //    public User(String name, String password, int age, String userId, String email, String picture) {
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    Toast.makeText(SignIn.this, "There is no account associated with that gmail.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
            }
        });



        //signup
        signupTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(SignIn.this,SignUp.class), SIGN_UP);

            }
        });


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == SIGN_UP && resultCode == RESULT_OK)
        {
            userid = getIntent().getStringExtra("UID");

            Intent intent = new Intent(SignIn.this,NavBar.class);
            intent.putExtra("postArrayList", postArrayList);
            intent.putExtra("userArrayList", userArrayList);


            startActivity(intent);
        }
        else Toast.makeText(SignIn.this," a problem occured try again", Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onPause() {
        super.onPause();

        if(stayConnect.isChecked())
        {
            SharedPreferences.Editor editor = sp.edit();  //create a table for the data
            editor.putString("username", userNameEditText.getText().toString());
            editor.putString("password", passwordEditText.getText().toString());
            editor.putBoolean("stayConnect", true);
            editor.commit();
        }
        else
        { SharedPreferences.Editor editor = sp.edit();  //create a table for the data
            editor.putString("username", "");
            editor.putString("password", "");
            editor.putBoolean("stayConnect", false);
            editor.commit();
        }
    }




    public void allDataDownload()
    {
     /*   Query q = myRef.child("users");
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dst: snapshot.getChildren() )
                {
                    User u = dst.getValue(User.class);
                    userArrayList.add(u);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });


        System.out.println("user "+userArrayList);
         myRef = database.getReference("Post");
         q = myRef;
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dst: snapshot.getChildren() )
                {
                    PostItem p = dst.getValue(PostItem.class);
                    postArrayList.add(p);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        System.out.println("post "+postArrayList);

*/
    }



    }


