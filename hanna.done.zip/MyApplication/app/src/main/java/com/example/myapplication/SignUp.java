package com.example.myapplication;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import static com.example.myapplication.SignIn.userid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity  {
    String email, password;
    private FirebaseAuth mAuth;
    Button SignUpButton;
    EditText FullnameEditText, PasswordEditText, AgeEditText, EmailEditText;
    TextView banner;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("DATA");
    static String userid = "";


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);


        mAuth = FirebaseAuth.getInstance();
        FullnameEditText = findViewById(R.id.Fullname);
        SignUpButton =  findViewById(R.id.SignUpBtn);
        PasswordEditText =  findViewById(R.id.Password);
        PasswordEditText = findViewById(R.id.Password);
        SignUpButton = findViewById(R.id.SignUpBtn);
        FullnameEditText = findViewById(R.id.Fullname);
        AgeEditText = findViewById(R.id.Age);
        EmailEditText = findViewById(R.id.Email);

        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(FullnameEditText.getText().toString().length()!=0 && PasswordEditText.getText().toString().length()!=0 &&AgeEditText.getText().toString().length()!=0 && EmailEditText.getText().toString().length()!=0  )
                {
                    if(validationInput(PasswordEditText.getText().toString(), AgeEditText.getText().toString()))
                    {
                        email = EmailEditText.getText().toString();
                        password = PasswordEditText.getText().toString();
                        mAuth.createUserWithEmailAndPassword(email, password)
                                .addOnCompleteListener(SignUp.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            Log.d(TAG, "createUserWithEmail:success");
                                            FirebaseUser user = mAuth.getCurrentUser();
                                            userid = user.getUid();
                                            //    public User(String name, String password, String age, String userId, String email, String picture) {
                                            User u  = new User(FullnameEditText.getText().toString(), password, AgeEditText.getText().toString(), userid, email, "");
                                            myRef.child("users").child(userid).setValue(u);
                                            Intent intent = new Intent();
                                            intent.putExtra("UID", userid);
                                            setResult(RESULT_OK,intent);
                                            finish();


                                        } else {
                                            // If sign in fails, display a message to the user.
                                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                            Toast.makeText(SignUp.this, "Authentication failed.",
                                                    Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    }
                }
            }
    });
    }




// check if the request code is same as what is passed  here


        public boolean validationInput(String passwordInput, String ageInput)
    {
        return passwordInput.length()>=6 && Integer.parseInt(ageInput)>0;
    }
}





