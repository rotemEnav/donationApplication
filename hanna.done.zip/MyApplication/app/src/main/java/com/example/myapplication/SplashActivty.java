package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.ArrayList;

public class SplashActivty extends AppCompatActivity  {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("DATA");
    ArrayList<User> arrayList = new ArrayList<>();
    boolean isFirstTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_activty);
        Query q = myRef.child("USER");


        new CountDownTimer(3000, 1000) {

            public void onTick(long millisUntilFinished) {
                if (isFirstTime) {
                    isFirstTime = false;
                    q.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            arrayList.clear();

                            for (DataSnapshot dst : snapshot.getChildren()) {
                                User u = dst.getValue(User.class);
                                arrayList.add(u);
                            }
                            System.out.println(arrayList);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                        }
                    });
                }
            }

            public void onFinish() {



                Intent intent = new Intent(SplashActivty.this, SignIn.class);
                Bundle args = new Bundle();
                args.putSerializable("ARRAYLIST",(Serializable)arrayList);
                intent.putExtra("BUNDLE",args);
                startActivity(intent);



            }
        }.start();



    }
}
