package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private final Context context;
    private final ArrayList<User> courseModelArrayList;




    public UserAdapter(Context context, ArrayList<User> courseModelArrayList) {
        this.context = context;
        this.courseModelArrayList = courseModelArrayList;
    }


    @NonNull
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.ViewHolder holder, int position) {
        User u = courseModelArrayList.get(position);
        holder.userName.setText(u.getName());
        holder.userMail.setText("" + u.getEmail());
        holder.userIV.setImageResource(Integer.parseInt(u.getPicture()));



    }


    @Override
    public int getItemCount() {
        return 0;
    }




    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView userIV;
        private final TextView userName;
        private final TextView userMail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            userIV = itemView.findViewById(R.id.idUserImage);
            userName = itemView.findViewById(R.id.idUserName);
            userMail = itemView.findViewById(R.id.iduserMail);
        }
    }



}



